#include <math.h>

#define sensorPin A0
#define BETA 3950

int ledArray[] = {4,5,6,7,8,9,10,11,12,13};
#define minTemp 20
#define maxTemp 40

void setup() {
  for (int i = 0; i < 10; i++) {
    pinMode(ledArray[i], OUTPUT);
  }
}

void loop() {
  int analogValue = analogRead(sensorPin);
  float celsius = 1 / (log(1 / (1023.0 / analogValue - 1)) / BETA + 1.0 / 298.15) - 273.15;
  
  int ledCount = map(celsius, minTemp, maxTemp, 0, 10);
  if(ledCount < 0) ledCount = 0;
  if(ledCount > 10) ledCount = 10;

  for (int i = 0; i < 10; i++) {
    if (i < ledCount)
      digitalWrite(ledArray[i], HIGH);
    else
      digitalWrite(ledArray[i], LOW);
  }

  delay(10);
}
